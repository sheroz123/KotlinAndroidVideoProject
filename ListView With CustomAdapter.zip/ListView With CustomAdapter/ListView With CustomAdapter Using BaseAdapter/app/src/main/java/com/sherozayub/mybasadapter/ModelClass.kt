package com.sherozayub.mybasadapter

class ModelClass(
        var imageID: Int? = 0,
        var name: String? = "Tital",
        var description: String? = "Description")