package com.sherozayub.mybasadapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView

class CustomAdapter(var ctx:Context,var myArrayList: ArrayList<ModelClass>) : BaseAdapter (){
    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        var view: View=LayoutInflater.from(ctx).inflate(R.layout.list_item, null, false)
        var imgView: ImageView=view?.findViewById(R.id.id_imageItem)
        var nameItem: TextView=view?.findViewById(R.id.id_nameItem)
        var descriptionItem: TextView=view?.findViewById(R.id.id_descriptionItem)

        var item: ModelClass=myArrayList.get(position)

        println(item.toString())
        println(view)

        if (item.imageID!=null)
        {
            imgView.setImageResource(item?.imageID!!)
        }
        nameItem.text = item.name
        descriptionItem.text = item.description

        return view
    }

    override fun getItem(position: Int): Any {
        return myArrayList.get(position)
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getCount(): Int {
        return myArrayList.size
    }
}