package com.sherozayub.mybasadapter

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.ListView

class MainActivity : AppCompatActivity() {

    var myList : ListView? = null
    var dataList : ArrayList<ModelClass> = ArrayList()
    var mAdapter : CustomAdapter?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        myList = findViewById(R.id.id_listview)
        mAdapter = CustomAdapter(this@MainActivity, dataList)

        dataList.add(ModelClass(R.drawable.car_placeholder,"Name Title 1","Title Description 1"))
        dataList.add(ModelClass(R.drawable.car_placeholder,"Name Title 2","Title Description 2"))
        dataList.add(ModelClass(R.drawable.car_placeholder,"Name Title 3","Title Description 3"))
        dataList.add(ModelClass(R.drawable.car_placeholder,"Name Title 4","Title Description 4"))
        dataList.add(ModelClass(R.drawable.car_placeholder,"Name Title 5","Title Description 5"))
        dataList.add(ModelClass(R.drawable.car_placeholder,"Name Title 6","Title Description 6"))
        dataList.add(ModelClass(R.drawable.car_placeholder,"Name Title 7","Title Description 7"))


                myList?.adapter = mAdapter




    }
}
